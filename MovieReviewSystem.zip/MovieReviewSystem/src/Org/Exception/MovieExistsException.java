package Org.Exception;

public class MovieExistsException extends Exception {



    public MovieExistsException(String message) {
        super(message);
    }


}
