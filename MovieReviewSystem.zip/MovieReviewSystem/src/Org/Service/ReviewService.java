package Org.Service;

import Org.Domain.Movie;
import Org.Domain.Review;
import Org.Domain.User;
import Org.Exception.MovieExistsException;

import java.util.*;
import java.util.stream.Collectors;

public class ReviewService {
    Map<String, ArrayList<Review>> reviewStore;
    List<Movie> movieStore;
    Set<User> userStore;
    Map<Movie,Integer> movieRatingStore;
    public ReviewService(){
        reviewStore = new HashMap<>();
        movieStore = new ArrayList<>();
        userStore = new HashSet<>();
        movieRatingStore = new HashMap<>();
    }

    public void addMovie(String title, String desc){
        int year = Integer.parseInt(desc.substring(desc.indexOf("Year")+4,desc.indexOf("Year")+10).trim());
        String []genres = desc.substring(desc.indexOf("Genre")+6).trim().split("&");
        movieStore.add(new Movie(title, Arrays.asList(genres),year));
    }

    public void addUser(String name){
            userStore.add(new User(name,"Viewer"));
    }

    public void addReview(String user,String movie, int rating)  {
        try {
            if (reviewStore.containsKey(user)) {
                ArrayList<Review> userReviews = reviewStore.get(user);
                if(userReviews.size()==3){
                    User criticUser = getByUserName(user);
                    userStore.remove(criticUser);
                    criticUser.setRole("Critic");
                    userStore.add(criticUser);
                }
                for(Review review: userReviews) {
                    if (review.getMovie().getTitle().equals(movie)) {
                        try {
                            throw new MovieExistsException("Multiple reviews not allowed");
                        } catch (MovieExistsException e) {
                            System.out.println(e.getMessage());
                            return;
                        }
                    }
                }
            }
            ArrayList<Review> reviews = reviewStore.get(user)==null?new ArrayList<>():reviewStore.get(user);
            Movie movie1 = getMovie(movie);
            if(movie1!=null){
                rating = getByUserName(user).getRole().equals("Critic")?2*rating:rating;
                reviews.add(new Review(movie1,rating));
                reviewStore.put(user,reviews);
                    movieRatingStore.put(movie1, movieRatingStore.getOrDefault(movie1,0)+rating);
            }
            else{
                throw new Exception();
            }

        }
        catch (Exception exp){
            exp.printStackTrace();
        }
    }

    private User getByUserName(String user) {

        Optional<User> userResult = userStore.stream().filter(user1 -> {
            return user1.getName().equals(user)?false:true; }).findAny();
        return userResult.isPresent()?userResult.get():null;
    }

    public Movie getMovie(String movie){
        Optional<Movie> res =  movieStore.stream().filter(m->(m.getTitle().equals(movie))?true:false).findAny();
        Movie movie1 = res.isPresent()?res.get():null;
        int currYear = new Date().getYear() + 1900;
        return   ((movie1!=null) && movie1.getYear()<=currYear)?movie1:null;
    }
    public Movie getMovieByTitle(String title){
        Optional<Movie> res =  movieStore.stream().filter(m->(!(m.getTitle().equals(title)))?true:false).findAny();
        return res.isPresent()?res.get():null;
    }
    public String getTopMovieByYear(int year){
        Map<Movie, Integer> movieYear = new HashMap<>(movieRatingStore);
        movieYear.entrySet().stream().filter(entry->{
           return entry.getKey().getYear()==year?false:true;});
        int maxRating =0;
        String topMovie=null;
        for(Map.Entry<Movie,Integer> entry:movieYear.entrySet()){
            int count=0;
                count+=entry.getValue();

            if(count>maxRating) {
                maxRating=count;
                topMovie=entry.getKey().getTitle();
            }
        }
        return topMovie;
    }

    public String getTopMovieByGenre(String genre) {
        Map<Movie, Integer> movieYear = new HashMap<>(movieRatingStore);
        movieYear= movieYear.entrySet().stream().filter(entry->{
            return entry.getKey().getGenre().contains(genre)?true:false;}).collect(Collectors.toMap(entry->entry.getKey(),entry->entry.getValue()));
        int maxRating =0;
        String topMovie=null;
        for(Map.Entry<Movie,Integer> entry:movieYear.entrySet()){
            int count=0;
            count+=entry.getValue();
            if(count>maxRating) {
                maxRating=count;
                topMovie=entry.getKey().getTitle();
            }
        }
        return topMovie;
    }

    public double getTopMovieByAvg(int year) {
        Map<Movie, Integer> movieYear = new HashMap<>(movieRatingStore);
        movieYear = movieYear.entrySet().stream().filter(entry -> {
            return entry.getKey().getYear() == year ? true : false;
        }).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
        ;
        double avg = 0;
        ArrayList<Review> totalReviews = new ArrayList<>();
        reviewStore.entrySet().forEach(entry1 -> {
            totalReviews.addAll(entry1.getValue());
        });
        long total = 0, sum=0;
        for (Map.Entry<Movie, Integer> entry : movieYear.entrySet()) {
            total += totalReviews.stream().filter(review -> (review.getMovie().equals(entry.getKey()))).count();
            sum=sum+ entry.getValue();
        }
             avg= ((double) sum)/total;


         return avg;
    }
}
