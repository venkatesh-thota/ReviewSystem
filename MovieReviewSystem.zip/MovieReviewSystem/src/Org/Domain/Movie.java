package Org.Domain;

import java.util.ArrayList;
import java.util.List;

public class Movie {
    String title;
    List<String> Genre;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    int year;
    public Movie() {
    }

    public Movie(String title, List<String> Genre, int year) {
        this.title = title;
        this.Genre = Genre;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String>  getGenre() {
        return Genre;
    }

    public void setGenre(List<String>  genre) {
        this.Genre = genre;
    }
}
