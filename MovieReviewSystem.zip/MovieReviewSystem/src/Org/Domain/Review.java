package Org.Domain;

public class Review {
    Movie movie;
    int Rating;

    public Review(Movie movie, int rating) {
        this.movie = movie;
        Rating = rating;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public int getRating() {
        return Rating;
    }

    public void setRating(int rating) {
        Rating = rating;
    }
}
