package Org.Domain;

public class User {
   public  String Name;
   public  String Role;

    public User(String name, String role) {
        Name = name;
        Role = role;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getRole() {
        return Role;
    }

    public void setRole(String role) {
        Role = role;
    }
}
